var URLIST = {
  user_login: 'http://localhost:8000/admin/login',
  user_logout: 'http://localhost:8000/admin/logout',
  user_getuser: 'http://localhost:8000/admin/getuser',
  user_editInfo: 'http://localhost:8000/admin/userinfo_edit',

  url_article_edit: 'http://localhost:8000/admin/article_edit',
  url_article_search: 'http://localhost:8000/admin/search',

  article_count: 'http://localhost:8000/admin/article_count',
  article_search: 'http://localhost:8000/admin/search',
  article_del: 'http://localhost:8000/admin/article_delete',
  article_publish: 'http://localhost:8000/admin/article_publish',

  category_add: 'http://localhost:8000/admin/category_add',
  category_edit: 'http://localhost:8000/admin/category_edit',
  category_search: 'http://localhost:8000/admin/category_search',
  category_del: 'http://localhost:8000/admin/category_delete'
};
